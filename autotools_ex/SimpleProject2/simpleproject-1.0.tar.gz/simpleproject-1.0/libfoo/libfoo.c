/*
 * =====================================================================================
 *
 *       Filename:  libfoo.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/07/2018 17:16:02
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <stdlib.h>

void display_stuff(char stuff[])
{
	printf("%s\n", stuff);
}

